Blockly.Msg.IPORT_DIGITAL_READ_MESSAGE = "อ่านค่าดิจิทัลที่ช่อง %1";
Blockly.Msg.IPORT_DIGITAL_READ_TOOLTIP = "อ่านค่าดิจิทัลจากช่องใด ๆ บน KidBright32";

Blockly.Msg.IPORT_DIGITAL_WRITE_MESSAGE = "เขียนค่าดิจิทัลที่ช่อง %1 เป็น %2";
Blockly.Msg.IPORT_DIGITAL_WRITE_TOOLTIP = "เขียนค่าดิจิทัลไปที่ช่องใด ๆ บน KidBright32";

Blockly.Msg.IPORT_ANALOG_READ_MESSAGE = "อ่านค่าแอนะล็อกที่ช่อง %1";
Blockly.Msg.IPORT_ANALOG_READ_TOOLTIP = "อ่านค่าแอนะล็อก 0 ถึง 4095 จากช่องใด ๆ บน KidBright32";

Blockly.Msg.IPORT_ANALOG_WRITE_MESSAGE = "เขียนค่าแอนะล็อกที่ช่อง %1 เป็น %2";
Blockly.Msg.IPORT_ANALOG_WRITE_TOOLTIP = "เขียนค่าแอนะล็อก 0 ถึง 1023 ไปที่ช่องใด ๆ บน KidBright32";

Blockly.Msg.IPORT_SERVO_MESSAGE = "ตั้งเซอร์โวช่อง %1 หมุนไปที่ %2 องศา";
Blockly.Msg.IPORT_SERVO_TOOLTIP = "";

Blockly.Msg.IPORT_SERVO_CALIBRATE_MESSAGE = "ตั้งเซอร์โวช่อง %1 ปรับเวลาเป็น ( %2 , %3 )";
Blockly.Msg.IPORT_SERVO_CALIBRATE_TOOLTIP = "";

Blockly.Msg.IPORT_USB_WRITE_MESSAGE = "เขียนยูเอสบี สถานะ %1";
Blockly.Msg.IPORT_USB_WRITE_ON_MESSAGE = "เปิด";
Blockly.Msg.IPORT_USB_WRITE_OFF_MESSAGE = "ปิด";
Blockly.Msg.IPORT_USB_WRITE_TOOLTIP = "";

Blockly.Msg.IPORT_USB_TOGGLE_MESSAGE = "สลับสถานะยูเอสบี";
Blockly.Msg.IPORT_USB_TOGGLE_TOOLTIP = "";

Blockly.Msg.IPORT_USB_READ_MESSAGE = "อ่านสถานะยูเอสบี";
Blockly.Msg.IPORT_USB_READ_TOOLTIP = "";

Blockly.Msg.IPORT_USB_ANALOG_WRITE_MESSAGE = "เขียนค่าแอนะล็อกยูเอสบี %1";
Blockly.Msg.IPORT_USB_ANALOG_WRITE_TOOLTIP = "";
